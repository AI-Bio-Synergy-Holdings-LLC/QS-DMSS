# Scientific falsification pilot result

Outcome: **NOT_FALSIFIED_WITHIN_SCOPE**. Scientific validation: **NOT_ESTABLISHED**.

Source: `48d7ab5d10da189caddbcad1dd6622e58d204940`. Candidate wheel SHA-256: `1c269bb96cec6e262fe19292ee4b290450df14d3b80e4f2924c278caeee5cb2f`.

| Exercise | Cases | Not falsified within scope | Failed | Inconclusive |
| --- | ---: | ---: | ---: | ---: |
| fft | 72 | 72 | 0 | 0 |
| graph | 15 | 15 | 0 | 0 |
| evolution | 2 | 2 | 0 | 0 |

Wolfram: NOT_EXECUTED by this runner; no cross-tool approval is implied.
Human disposition: PENDING. AI-assisted maintainer evidence is not independent review.
See results.json for every case, negative control, environment and limitation.
measurements.npz retains reference/candidate matrices, projectors and trajectories.
Hashes establish byte integrity only, not scientific correctness or authorship.
