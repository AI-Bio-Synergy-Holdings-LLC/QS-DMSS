# QS-DMSS Fractal SSFM QPU Request Bundle

Status: **review only; never submitted**

This bundle maps the simulator-validated Fractal SSFM reference circuit
onto a provider-neutral five-qubit topology. It does not contact a provider,
read credentials, estimate provider pricing, or submit a QPU job.

## Review Summary

- Request ID: `qpu-546fe4a787863b29`
- Source profile: `fractal-fuzzy-4x4-linear`
- Target profile: `generic-linear-5q`
- Requested shots: `1024`
- Logical circuit: `4` qubits, depth `9`
- Target circuit: `5` qubits, depth `147`
- Target CX count: `144`
- Authorized provider spend: `$0.00`

## Review Checklist

1. Inspect `qpu-request.json` for the target, shot, cost, and credential policies.
2. Inspect `artifacts/fractal-fuzzy-target.openqasm` and the resource deltas.
3. Confirm the generic coupling map and basis gates are appropriate for review.
4. Review `reference-validation/` before treating the circuit mapping as meaningful.
5. Do not add provider tokens, account identifiers, or private calibration data.
6. A future provider adapter requires a separate explicit approval and security review.

## Claim Boundary

Review-only hardware-target transpilation of the validated Fractal SSFM sidecar profile. It is not a provider connection, QPU submission, hardware calibration, execution result, cost estimate, quantum advantage claim, or scientific validation of the underlying physical model.
