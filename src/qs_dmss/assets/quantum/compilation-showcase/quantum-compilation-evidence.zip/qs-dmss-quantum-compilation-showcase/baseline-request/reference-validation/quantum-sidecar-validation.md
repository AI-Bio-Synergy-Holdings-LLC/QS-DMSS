# QS-DMSS Fractal SSFM Quantum-Readiness Sidecar

Overall status: **PASS**
Profile: `fractal-fuzzy-4x4-linear`
Generated at: `2026-07-13T02:26:17.687701+00:00`

This local sidecar compares one 4x4, linear, phase-only fuzzy-potential
Fractal SSFM Strang step against an exact Qiskit statevector and deterministic
Aer sampling. The synthetic noise run is diagnostic only.

## Exact Encoding Agreement

- Global-phase-aligned state L2 error: `7.726948e-16`
- Density mean absolute error: `6.135653e-17`
- Quantum state norm error: `9.992007e-16`

## Sampling Diagnostics

- Shots: `1024`
- Ideal total-variation distance: `3.705832e-02`
- Synthetic-noise total-variation distance: `2.333795e-01`
- Conservative 95% binomial half-width: `3.062500e-02`

## Circuit Resources

- Qubits: `4`
- Depth after basis decomposition: `87`
- Two-qubit gates: `82`
- Operations: `{"cx": 82, "u": 57}`

## Checks

| Check | Status | Detail |
| --- | --- | --- |
| profile:phase-only-fuzzy-potential | PASS | profile excludes nonlinear feedback, masks, and de-alias filtering |
| encoding:statevector-agreement | PASS | L2 error 7.726948e-16 <= 1.000000e-10 |
| encoding:density-agreement | PASS | density MAE 6.135653e-17 <= 1.000000e-10 |
| encoding:norm-conservation | PASS | quantum state norm error 9.992007e-16 |
| execution:simulator-only | PASS | local Statevector and Aer simulators; submitted=false |

## Claim Boundary

Simulator-only quantum-readiness validation of one small, linear, phase-only Fractal SSFM Strang step. It is not QPU execution, quantum advantage, nonlinear Schrodinger-Poisson simulation, peer-reviewed physical validation, or validation of hard/soft mask geometry modes.

No cloud account, QPU, provider credential, or remote submission was used.
